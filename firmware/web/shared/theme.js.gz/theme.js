document.documentElement.dataset.theme="dark";const e=()=>"dark";export{e as theme};
